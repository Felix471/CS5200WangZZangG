export interface Clinic {
    clinicId: number;
    clinicName: string;
    address: string;
    clinicContactNumber: string;
}
