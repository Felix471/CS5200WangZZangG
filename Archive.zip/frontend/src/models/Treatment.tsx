export interface Treatment {
    treatmentId: number;
    description: string;
    dentistId: number;
    appointmentId: number;
}