export interface ProcedureCatalog {
    procedureId: number;
    procedureName: string;
    description: string;
    standardCost: number;
}