export interface Dentist {
    dentistId: number;
    firstName: string;
    lastName: string;
    licenseNumber: string;
    description: string;
    phoneNumber: string;
    email: string;
    address: string;
    clinicId: number;
}
