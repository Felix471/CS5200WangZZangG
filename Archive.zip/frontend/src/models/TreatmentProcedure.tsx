export interface TreatmentProcedure {
    procedureId: number;
    treatmentId: number;
}