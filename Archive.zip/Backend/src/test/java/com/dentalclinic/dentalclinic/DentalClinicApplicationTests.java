package com.dentalclinic.dentalclinic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DentalClinicApplicationTests {

	@Test
	void contextLoads() {
	}

}
