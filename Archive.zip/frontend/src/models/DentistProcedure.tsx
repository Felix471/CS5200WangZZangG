export interface DentistProcedure {
    procedureId: number;
    dentistId: number;
}
